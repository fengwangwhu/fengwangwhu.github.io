package com;
import java.util.Random;

public class ALPSO {
	
	public class Population {
		public double[] position;
		public double[] velocity;		
		public double fitness;	
		public int tolerance;
		
		public Population(int DIM) {
			position = new double[DIM];
			velocity = new double[DIM];
		}		
	}
	
	final static int SIZE=20;		
	static int FEs = 0;
	final static int numCompete = 0;
	final static int TMax = 20000;
	final static double c1 = 2.0;
	final static double c2 = 2.0;
	final static double w0 = 0.9;
	final static double w1 = 0.4;
	final static int T = 10;
	final static int DIM = 30;
	
	public Population[] particle = new Population[SIZE]; 
	public Population[] pbestParticle = new Population[SIZE]; 
	public Population gBest; 
	public Population competitor;
		
	public void Init(int num, double fhb) throws Exception {
		double flb = -fhb;
		for(int i=0;i<SIZE;i++) {
			particle[i]=new Population(DIM);
			pbestParticle[i] = new Population(DIM);
		}
		gBest = new Population(DIM);
		competitor = new Population(DIM);
	
		for(int i = 0;i < SIZE; i++) {
			for(int j = 0; j < DIM; j++) {
				particle[i].position[j] = (Math.random() > 0.5) ?
						Math.random() * fhb : Math.random() * flb;
						
				particle[i].velocity[j] = 0.0;
				
				pbestParticle[i].position[j] = particle[i].position[j];
				
			} // end for DIM
			particle[i].fitness = CalFitness(DIM, particle[i], num);
			FEs++;  
			pbestParticle[i].fitness = particle[i].fitness;
		} // end for SIZE
		
		for(int j = 0; j < DIM; j++) {
			gBest.position[j] = particle[0].position[j];
		}
		gBest.fitness = particle[0].fitness;
		gBest.tolerance = 0;
		for(int i = 0 ; i < SIZE; i++ ){
			if(gBest.fitness > pbestParticle[i].fitness) {
				for(int j = 0; j < DIM; j++) {
					gBest.position[j] = pbestParticle[i].position[j];
				}
				gBest.fitness = pbestParticle[i].fitness;

			}
		}
	}

	public void Update(int num) throws Exception {				
		for(int i=0;i<SIZE;i++){
			particle[i].fitness = CalFitness(DIM , particle[i],num);
			FEs++;
			
			if(pbestParticle[i].fitness > particle[i].fitness) {
				for(int j = 0; j < DIM; j++) {
					pbestParticle[i].position[j] = particle[i].position[j];
				}
				pbestParticle[i].fitness = particle[i].fitness;
			}
			else {
				gBest.tolerance++;
			}
			//update gBest
			if(gBest.fitness > pbestParticle[i].fitness) {
				for(int j = 0; j < DIM; j++) {
					gBest.position[j] = pbestParticle[i].position[j];
				}
				gBest.fitness = pbestParticle[i].fitness;
			}
		}	
	}
	
	
	public void UpdatePosiAndVelo(double fhb, int t) {
		double flb = -fhb;
		double vmax = 0.5*fhb;
		double vmin = 0.5*flb;
		double w = w0 - (w0-w1) * t / TMax;		
		for(int i = 0; i < SIZE; i++) {
			for(int j = 0; j < DIM; j++) {
				particle[i].velocity[j] = w*particle[i].velocity[j] + 
						c1*Math.random()*(pbestParticle[i].position[j] - particle[i].position[j]) +
						c2*Math.random()*(gBest.position[j] - particle[i].position[j]);
				
				if(particle[i].velocity[j]>vmax){
					particle[i].velocity[j]=vmax; 
				}else if(particle[i].velocity[j]<vmin){
					particle[i].velocity[j]=vmin;
				}
				
				particle[i].position[j] = particle[i].position[j] + particle[i].velocity[j];
				
				if(particle[i].position[j]>fhb){
					particle[i].position[j]=fhb;
				}else if(particle[i].position[j]<flb){
					particle[i].position[j]=flb;
				}
			}		
		}
	}	
	
	// Tolerance based search direction adjustment mechanism
	public void UpdatePresident(int num, double pro, double fhb,int t) throws Exception {
		double currentExpT = Math.exp(gBest.tolerance) -1;
		double maxExpT = Math.exp(T) - 1;
		
		if(currentExpT / maxExpT > Math.random()) {
			CreateCompetitor(DIM, num, pro, fhb,t);
		}
	}
	
	// Self-learning based candidate generation strategy
	public void CreateCompetitor(int DIM, int num, double pro, double fhb,int t) throws Exception {
		double flb = -fhb;
		double [] tempSigma = new double[DIM];
		double [] tempAverage = new double[DIM];
		Random R = new Random();		
		
		for(int j = 0; j < DIM; j++) {		
			double r = Math.random();
			double averagerPbestPosit = 0.0;
			double sigma = 0.0;	
			double [] tempPbestParticleJ = new double[SIZE];   // dimension J's tempt array
			
			for(int i = 0 ; i < SIZE; i++){
				tempPbestParticleJ[i] = pbestParticle[i].position[j];
				averagerPbestPosit = averagerPbestPosit + pbestParticle[i].position[j];
			}
			averagerPbestPosit = averagerPbestPosit  / SIZE;		
			for(int i = 0; i <SIZE; i++){
				sigma += (tempPbestParticleJ[i] - averagerPbestPosit) * (tempPbestParticleJ[i] - averagerPbestPosit);
			}
			sigma = sigma  / SIZE;
			
			tempSigma[j] = sigma;
			tempAverage[j] = averagerPbestPosit;
			
			if(r < pro){
				competitor.position[j] = Math.sqrt(sigma)*R.nextGaussian() + averagerPbestPosit;					
			}
			else{
				competitor.position[j] = gBest.position[j];
			}
			
			if(competitor.position[j]>fhb){
				competitor.position[j]=fhb;
			}else if(competitor.position[j]<flb){
				competitor.position[j]=flb;
			}
	
		}	
		UpdatePresident2(DIM, num, fhb,t);
	}
	
	//  Competitive learning based prediction strategy
	public void UpdatePresident2(int DIM, int num, double fhb,int t) throws Exception {
		double flb = -fhb;
		double vmax = 0.5*fhb;
		double vmin = 0.5*flb;
		double w = w0 - (w0-w1) * t / TMax;
		
		Population[] old_particle = new Population[SIZE]; 
		Population[] old_pbestParticle = new Population[SIZE];
		for(int i=0;i<SIZE;i++){
			old_particle[i]=new Population(DIM);
			old_pbestParticle[i] = new Population(DIM);
		} // end for
	
		for(int i = 0; i < SIZE; i++) {
			for(int j = 0; j < DIM; j++) {
				old_particle[i].position[j] = particle[i].position[j];
				old_particle[i].velocity[j] = particle[i].velocity[j];
				
				old_pbestParticle[i].position[j] = pbestParticle[i].position[j];
			}  
			old_particle[i].fitness = particle[i].fitness;
			old_pbestParticle[i].fitness = pbestParticle[i].fitness;
		} 
		
		competitor.fitness = CalFitness(DIM, competitor, num);
		FEs++;
		int T = 2; // challenge times
		int countGrow = 0;
		for(int m = 1; m <= T; m ++) {
			for(int i = 0; i < SIZE; i ++) {			
				for(int j = 0; j < DIM; j ++) {
					old_particle[i].velocity[j] = w*old_particle[i].velocity[j] + 
							c1*Math.random()*(old_pbestParticle[i].position[j] - old_particle[i].position[j]) +
							c2*Math.random()*(competitor.position[j] - old_particle[i].position[j]);
				
					if(old_particle[i].velocity[j]>vmax){
						old_particle[i].velocity[j]=vmax;
					}else if(old_particle[i].velocity[j]<vmin){
						old_particle[i].velocity[j]=vmin;
					}				
					
					old_particle[i].position[j] = old_particle[i].position[j] + old_particle[i].velocity[j];			
					
					if(old_particle[i].position[j]>fhb){
						old_particle[i].position[j]=fhb;
					}else if(old_particle[i].position[j]<flb){
						old_particle[i].position[j]=flb;
					}
				} // end for DIM
			} // end for SIZE	
			for(int i = 0 ; i < SIZE; i++){
				old_particle[i].fitness = CalFitness(DIM, old_particle[i], num);
				FEs++;  //evaluation function����
				if(old_pbestParticle[i].fitness>old_particle[i].fitness) { // update pBest
					for(int j = 0; j < DIM; j++) {
						old_pbestParticle[i].position[j] = old_particle[i].position[j];
					} 	 		
					old_pbestParticle[i].fitness = old_particle[i].fitness;
					countGrow ++;
				} // end if
			
				if(competitor.fitness>old_pbestParticle[i].fitness) { // update gBset 
					for(int j = 0; j < DIM; j++) {
						competitor.position[j] = old_pbestParticle[i].position[j];
					} 
					competitor.fitness = old_pbestParticle[i].fitness;
				} // end if
			}//end for size
					
		} // end for T
		if( (countGrow != 0) && (competitor.fitness < gBest.fitness) ) {
			gBest.fitness = competitor.fitness;
			for(int j = 0; j < DIM; j++){
				gBest.position[j] = competitor.position[j];
			}
			for(int i = 0; i < SIZE;i++){
				for(int j = 0; j <DIM; j++){
					particle[i].position[j] = old_particle[i].position[j];
					pbestParticle[i].position[j] = old_pbestParticle[i].position[j];
				}
				particle[i].fitness = old_particle[i].fitness;
				pbestParticle[i].fitness = old_pbestParticle[i].fitness;
			}
		} 
		gBest.tolerance = 0;
	}

	public double CalFitness(Integer DIM, Population particle,int num) throws Exception {
		double fit = 0.0;
		// fit = testFunction(particle)
		return fit;
	}

	
	public static double SetBorder(int num) {
		double fhb = 0.0;
		
		return fhb;
	}

}